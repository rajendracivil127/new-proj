<script>
  var searchForm = document.forms['search-movies'][0];
  searchForm.addEventListener('keyup', function(e)){
    var searchItem = list.querryselectorAll('li');
  var filter = e.target.value.toUppercase();
  }
  Array.form(searchItem).forEach(function (text)){
      var textval = text.firstElementChild.textcontent;
      if (textval.toUpperCase().indexOf(filter) > -1){
    text.style.display = 'block';
      } else {
    text.style.display = 'none';

      }


      }
  var list = document.querrySelector('#movie-list ul');
  list.addEventListener('click', function (e)){
    if (e.target.className === 'delete'){
      var li = e.target.parentElement;
  list.removeChild(li);
    }
  }
  var hideform = document.querrySelector('#add-movie #hide');
  hideform.addEventListener('click', function (e)){
    if (list.style.display == "none"){
    list.style.display = "block";
    } else{
    list.style.display = "none";
    }
    }
  var addForm = document.forms['add-movie'];
  addForm.addEventListener('submit' , function (e)){
    var value = addForm.querrySelector('input[type="text"]').var
  var li =document.createElement('li');
  var movieName = document.createElement('span');
  var deletebtn = document.createElement('span');
  li.appendChild(movieName);
  li.appendChild(deletebtn);
  li.appendChild(li);
  movieName.textContent = value;
  deletebtn.textContent = 'delete';
  movieName.classListadd('name');
  deletebtn.classListadd('delete');
</script>