<script>
function myFunction() {
  var list = document.getElementByClassName("item");
  console.log(list);
  var listArray = [];
  for(var i = 0; i < list.length; i++){
    console.log(list[i].innerHTML);
  listArray.push(list[i].innerHTML);
  if (list[i].innerHTML = 'Bandersnatch'){
      break;
    }
  document.querryselector(".item").innerHTML = 'movie4';
  document.getElementByClassName("item").addEventListener('click', myFunction);
  }
</script>